植物管理工具－公開部署版

Render 部署：
1. 將此資料夾內全部檔案上傳到 GitHub Repository
2. Render → New → Static Site
3. 連接該 GitHub Repository
4. Build Command：留空（若必填可輸入 echo "No build needed"）
5. Publish Directory：.
6. Deploy

網站首頁檔案：index.html

注意：
- 此版本為純前端網站。
- 每位使用者的操作資料目前不會跨裝置、跨使用者同步。
- 若要所有同學共用同一份植物資料，需要加後端/雲端資料庫。
